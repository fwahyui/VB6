Demo MS Chart Program

You will need the following files on your computer for this to run.

MSVBVM60.DLL that comes with any VB 6 install to run the program (look in \Windows\system)
msgraph8.exe Office 97
msgraph8.olb Office 97

Function
========

The program demonstrates some of the ways that you can control MS Chart dynamically


Disclaimer
==========

The author of this program accepts no responsibility for damages resulting from 
the use of this product and makes no warranty or representation, either express 
or implied, including but not limited to, any implied warranty of merchantability or 
fitness for a particular purpose. This software is provided "AS IS", and you, 
its user, assume all risks when using it.

www.gr-fx.com
access@gr-fx.com