Microsoft Chart - Handle With Care  

Files associated with the Article On Manipulating MS Chart using Visual Basic 5/6

vbChart.hlp          ... The article in help format
grchart.ZIP          ... Another zip file with the VB project 


Garry Robinson
GR-FX Pty Limited
Australian Company Number:  070 303 196
Ph +61 2 9665 2871   Fax +61 2 9665 8448
Email   access@gr-fx.com 
Web www.gr-fx.com
PO Box 2121
Clovelly,  NSW, Australia





